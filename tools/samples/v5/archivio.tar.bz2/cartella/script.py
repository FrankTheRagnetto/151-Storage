def ciao():
    print('ciao da un archivio')
