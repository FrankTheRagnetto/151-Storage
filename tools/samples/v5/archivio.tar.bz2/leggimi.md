# Archivio di prova

Dentro un **7z**.
